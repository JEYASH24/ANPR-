from flask import Flask, render_template, request, jsonify, send_file
import csv
import os
from datetime import datetime

app = Flask(__name__)
image_folder = "Images"
toBeFound_csv_path = 'toBeFound.csv'
resultsFolder_csv_path = './resultsFolder.csv'


def remove_from_to_be_found(license_plate):
    lines = []
    with open(toBeFound_csv_path, 'r', newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row and row[0] != license_plate:
                lines.append(row)

    with open(toBeFound_csv_path, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(lines)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/process_license_plate', methods=['POST'])
def process_license_plate():
    data = request.get_json()
    license_plate = data.get('licensePlate')

    # Read the CSV file
    with open(resultsFolder_csv_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reversed(list(reader)):
            if row['detected_plate_number'] == license_plate:  
                # License plate found in the CSV file
                image_path = os.path.join(image_folder, row['image_name'])
                date_time = row['date_time']
                return jsonify({'message': 'License plate found in CSV file', 'image_path': image_path, 'date_time': date_time})
    
    # License plate not found in the CSV file
    return jsonify({'message': 'License plate not found in CSV file'})


@app.route('/append_to_be_found', methods=['POST'])
def append_to_be_found():
    data = request.get_json()
    license_plate = data.get('licensePlate')

    # Check if the license plate is already in the CSV file
    with open(toBeFound_csv_path, newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row and row[0] == license_plate:
                return jsonify({'message': 'License plate already exists in toBeFound.csv'})
    
    # Get the current date and time
    current_datetime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # Append the entered license plate number and the current date and time to toBeFound.csv
    with open(toBeFound_csv_path, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([license_plate, current_datetime])

    return jsonify({'message': 'License plate appended to toBeFound.csv'})


@app.route('/get_image')
def get_image():
    image_path = request.args.get('image_path')
    return send_file(image_path, mimetype='image/png') 


@app.route('/remove_from_to_be_found', methods=['POST'])
def remove_from_to_be_found_route():
    data = request.get_json()
    license_plate = data.get('licensePlate')
    remove_from_to_be_found(license_plate)
    return jsonify({'message': 'License plate removed from toBeFound.csv'})


if __name__ == '__main__':
    app.run(debug=False)
